create definer = root@localhost trigger altersuppliername
    after delete
    on supplier
    for each row
BEGIN
	UPDATE `hospital`.`returngoods`
	SET count = count - 1
	WHERE id=1;
    END;

